import React from 'react';
import FloatingButton from './FloatingButton';

function App() {
  return (
    <div className="App">
      <FloatingButton />
    </div>
  );
}

export default App;
